<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response;
Use App\File;

class FileController extends Controller
{

    public function index()
    {
        return view('multiple-file-upload');
    }

    public function fileStore(Request $request)
    {
       request()->validate([
        'fileName' => 'required',
        'fileName.*' => 'mimes:doc,docx,pdf,txt,jpeg,png,jpg,gif,svg'
       ]);
       
       if($request->hasfile('fileName'))
       {
         
         foreach ($request->file('fileName') as $key => $value) 
         {
   
           if ($files = $value) 
           {
               $destinationPath = 'public/files/'; // upload path
               $fileName = date('YmdHis') . "." . $files->getClientOriginalExtension();
               $files->move($destinationPath, $fileName);
               $save[]['file_name'] = "$fileName";
            }
         }

        }

        File::insert($save); // store file into mysql database

        return Redirect::to("multiple-file-upload")
        ->withSuccess('Files successfully uploaded.');

    }
}